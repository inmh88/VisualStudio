#dictionary
print("This program asks User for Name of User and adds to the the register")

person = {"first_name":"John", "last_name": "Green", "birth_year": 1979, "country_of_birth": "Canada"}

person["martital_status"] = "Married"

person["children"] = ["Natalie","Ethan"]

person["children"].append("Anna")

