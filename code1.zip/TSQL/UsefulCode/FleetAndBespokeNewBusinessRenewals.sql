USE [DataTeam]
GO

/****** Object:  StoredProcedure [WorkVolumesMI].[FleetAndBespokeNewBusinessRenewals]    Script Date: 09/07/2020 19:58:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VT
-- Create date: 21/06/2018
-- =============================================
CREATE PROCEDURE [WorkVolumesMI].[FleetAndBespokeNewBusinessRenewals]
	 @StartDateTime DATETIME
	,@EndDateTime DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	--Testing Dates
    --DECLARE  @StartDateTime DATETIME
	--,@EndDateTime DATETIME
	--SET @StartDateTime = CONVERT(dateTime,'2018-02-12 00:00:00.000')
	--SET @EndDateTime = CONVERT(dateTime,'2018-02-16 23:59:59.997')

	DECLARE @Starting DATE
	DECLARE @Ending DATE

	SET @Starting = CAST(@StartDateTime AS DATE)
	SET @Ending = CAST(@EndDateTime AS DATE)

	DECLARE @Results TABLE
	(
	 PolicystartDate DATE
	)

	;WITH cte_Dates AS 
	(
	  SELECT @Starting AS dt
	  UNION ALL
	  SELECT DATEADD(dd, 1, dt)
	  FROM cte_Dates s
	  WHERE DATEADD(dd, 1, dt) <= @Ending
	)

		INSERT INTO @Results (PolicystartDate)
		SELECT * 
		FROM cte_Dates


	;WITH cte_1
	AS
	(
	SELECT T1.PolicyStartDate, T2.Policy_ID FROM @Results T1 
	LEFT OUTER JOIN
	(
			SELECT DISTINCT
				 t0.[Policy_ID]
				,CAST(t0.[Policy_StartDateTime]	AS DATE) PolicyStartDate
			FROM [REPL_Fleet].[dbo].[V_SSRS_FleetReporting] t0 WITH(NOLOCK)
			WHERE 
				([ClientPremium_ReasonID] = 1)
				AND(NOT([ClientPremium_MadeInError] = 1))
				AND(CAST([Policy_StartDateTime] AS DATE) >= CAST(@StartDateTime AS DATE) 
				AND CAST([Policy_StartDateTime] AS DATE) <= CAST(@EndDateTime AS DATE))
		) T2 ON T1.PolicystartDate = T2.PolicyStartDate
	)

		SELECT PolicyStartDate, COUNT([Policy_ID]) AS NewBusinessCount FROM cte_1
		GROUP BY PolicyStartDate
		ORDER BY PolicyStartDate
END

GO

