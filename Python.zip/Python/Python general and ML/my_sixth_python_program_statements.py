print("This program calculates area and circumference of a circle")

import math

varRadius = float ( input("Please enter the Radius: ") )

constPi = math.pi

varArea = round( (constPi * varRadius**2) ,2)
varCircumference = round( 2*(constPi * varRadius) ,2)

print("The area is",varArea)
print("The circumference is",varCircumference)
