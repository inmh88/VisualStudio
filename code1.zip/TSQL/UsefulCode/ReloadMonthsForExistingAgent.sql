USE [DataTeam]
GO

/****** Object:  StoredProcedure [WorkVolumesMI].[ReloadMonthsForExistingAgent]    Script Date: 09/07/2020 19:59:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		VT
-- Create date: 20/11/2018
-- =============================================
CREATE PROCEDURE [WorkVolumesMI].[ReloadMonthsForExistingAgent] 
	
AS
BEGIN
	
	SET NOCOUNT ON;

  DECLARE @Forenames varchar(50),
		@Surname varchar(50),
		@ExtensionNumber int,
		@Output int

		SET @Forenames = 'David'
		SET @Surname = 'Mordey'

		DECLARE @monthCounter int
		DECLARE @WindowsUsername varchar(50)
		DECLARE @myDate Date
		DECLARE @myDays int
		DECLARE @AgentName varchar(50)
		SET @monthCounter = 1
		SET @WindowsUsername = RTrim(LTrim(@Forenames)) + '.' + RTrim(LTrim(@Surname))

	  --test if in Mitel Extension table first; 

		IF EXISTS (
					SELECT TOP 1 WindowsUsername
					FROM [DW_Mitel].[Dimension].[Extensions]
					WHERE WindowsUsername = @WindowsUsername AND ActiveFromDateTime <=GetDate() AND ActiveToDateTime > GetDate()
				  )
		BEGIN
	
			IF EXISTS (SELECT Top 1 RTrim(LTrim(AgentForenames)) + '.' + RTrim(LTrim(AgentSurname)) 
			FROM WorkVolumesMI.FleetAgentsMapping WHERE RTrim(LTrim(AgentForenames)) + '.' + RTrim(LTrim(AgentSurname)) = @WindowsUsername)
						
				BEGIN

					UPDATE WorkVolumesMI.FleetAgentsMapping
					SET Show = 1
					WHERE RTrim(LTrim(AgentForenames)) + '.' + RTrim(LTrim(AgentSurname)) = @WindowsUsername
		

				--check if current month is in existence
					IF EXISTS (
							SELECT id
							FROM [DataTeam].WorkVolumesMI.WorkVolumesStaffOvertime
							WHERE WindowsUsername = RTrim(LTrim(@Forenames)) + '.' + RTrim(LTrim(@Surname))
							AND [Year] = YEAR(GetDate()) AND [Month] = MONTH(GetDate())	 
						  )
					BEGIN
						SET @monthCounter = 1
					END
					ELSE
					BEGIN
						SET @monthCounter = 0
					END

					--Load up missing months to bring up to date
					WHILE @monthCounter < 4
						BEGIN

						SET @myDate = CONVERT(DATE, DateAdd(month,@monthCounter,GetDate()))

						SET @mydays = datediff(day, dateadd(day, 1-day(@myDate), @myDate),
									  dateadd(month, 1, dateadd(day, 1-day(@myDate), @myDate)))

						DECLARE @number INT
						SET @number = @myDays

						DECLARE @thisMonth TABLE
						(
						 [year] int
						,[month] int
						,[day] int
						)

						DECLARE @Agents TABLE
						(
						WindowsUsername varchar(50)
						)

						  ;WITH cte_Agents1
						AS
						(
						SELECT DISTINCT 
							  [ExtensionKey]
						  FROM [DW_Mitel].[Fact].[Fleet_ExtensionPerformanceByPeriod]
						  ), cte_Agents2
						  AS
						  (
						  SELECT DISTINCT
							   WindowsUsername
						  FROM [DW_Mitel].[Dimension].[Extensions] e INNER JOIN cte_Agents1 c
						  ON c.ExtensionKey = e.[key] INNER JOIN [DataTeam].[WorkVolumesMI].[FleetAgentsMapping] fa
						  ON fa.AgentForenames + '.' + fa.AgentSurname = e.WindowsUsername 
						  WHERE fa.Show = 1
						  )

							INSERT INTO @Agents(WindowsUsername)
							SELECT * FROM cte_Agents2
							ORDER BY WindowsUsername

							;WITH CTE AS (
							SELECT 1 AS [days]
							UNION ALL 
							SELECT [days] + 1
							FROM CTE
							WHERE [days] < @number)

							INSERT INTO @thisMonth([day])
							SELECT [Days]
							FROM CTE

							UPDATE @thisMonth
							SET [year] = Year(DateAdd(month,@monthCounter,GetDate()))
							WHERE [year] Is Null

							UPDATE @thisMonth
							SET [month] = Month(DateAdd(month,@monthCounter,GetDate()))
							WHERE [month] Is Null

							SET @monthCounter = @monthCounter + 1
						END

						INSERT INTO [WorkVolumesMI].WorkVolumesStaffOvertime ([WindowsUsername], [year], [month], [day])
							SELECT @WindowsUsername, [year], [month], [day] FROM @thisMonth ORDER BY [year], [month], [day] 
						 
						 --SELECT * FROM @thisMonth
				END
			END
		

END

GO

