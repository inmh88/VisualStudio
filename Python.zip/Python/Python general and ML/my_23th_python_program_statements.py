print("This program uses function blocks")

def say_hello(person):
    print("Hello! " + person + ", how are you doing?")

say_hello("Jeff")

###############################################################
def fahrtocelcius(fahr):
    celsius = (5 * (fahr - 32)) /9
    return celsius


print ( "Celsius: " , round( fahrtocelcius(100),2 ) )
print ( "Kelvin: " , round( fahrtocelcius(100) +273.5 ,2 ) )

###############################################################

def say_hello(person1, person2="The director"):
    print("Hello! " + person1 + ", how are you doing? " + person2 + " is waiting for you.")

say_hello("Jeff","Brian")
say_hello("Jeff")

