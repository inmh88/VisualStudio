
# This program uses various imported modules - the json, pprint, and requests modules.


import requests
r = requests.get("https://opentdb.com/api.php?amount=1&category=11&difficulty=easy&type=multiple")
#print(r.status_code)
#print(r.text)

import json
quiz = json.loads(r.text)
#print(quiz)


import pprint
pprint.pprint(quiz)



#print( quiz['results'][0]['quiz'] )
#print( quiz['results'][0]['correct_answer'] )

#print( quiz['results'][0]['category'] )

#print( quiz['results'][0]['incorrect_answers'] )
#print( quiz['results'][0]['incorrect_answers'][0] )


quizAnswer = str( quiz['results'][0]['correct_answer'] )

quizQuestion = str( quiz['results'][0]['question'] )

quizIncorrectsList = []
quizIncorrectCount = len( quiz['results'][0]['incorrect_answers'] )
quizIncorrectIndex = 0

while quizIncorrectIndex < quizIncorrectCount:  
    quizIncorrectsList.append( str( quiz['results'][0]['incorrect_answers'][quizIncorrectIndex] ) )
    #print(quizIncorrects[incorrectIdx])
    #print(quizIncorrects)
    quizIncorrectIndex += 1

print(quizAnswer)
print(quizIncorrectsList)

quizIncorrectsList.sort()
for item in quizIncorrectsList:
    print(item)

print(quizAnswer)