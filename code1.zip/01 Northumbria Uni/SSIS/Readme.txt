SITS SSIS packages
------------------

Packages are "EncryptSensitiveWithPassword"


The password to open the packages in BIDS is:

sunshine


