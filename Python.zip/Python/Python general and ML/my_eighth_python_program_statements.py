print("This program asks User for birthday dd-mm-yyyy and prints the month")


tupleMonths = ("January","Feburary","March","April","May","June","July","August","September","October","November","December")
varInputBirthday = input("Please enter your Birthday DD-MM-YYYY : ") 

tupleIndex = (int( varInputBirthday[3:5] ) -1)
bd_month = tupleMonths[tupleIndex]

print("Your birth month is:", bd_month)