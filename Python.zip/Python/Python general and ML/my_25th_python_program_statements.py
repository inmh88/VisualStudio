print("This program uses External Modules")

### MatPlotLib

import matplotlib.pyplot as plt

x = [1,2,3,4]
y = [1500,1200,1100,1800]

legend = ["January","February","March","April"]

#plt.plot(x,y)
plt.bar(x,y)
plt.ylabel("Sales in US$")
plt.title("Monthly Sales")
plt.xticks(x,legend)
plt.show
