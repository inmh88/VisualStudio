print("This program uses Internal Modules")


## TIME Module

import time as t
t.localtime()
time_now = t.localtime()

print("Transaction completed at", str(time_now.tm_hour) + "h" + str(time_now.tm_min) + "m")

###########################################################################################

time_now1 = t.time()
delivery_time = time_now1 + (86400 * 7)
print ( t.localtime(delivery_time) )

t.sleep(5)


