print("This program uses for loops as an excercise for loops")

people=[]
while len(people) < 8:
    person = input("Type the name of person: " )
    people.append(person)

import random
randomName = random.choice(people) 
print("Selecting a random name: ",randomName)

##########################################################################

print("This program asks user to guess colour")

import random
colourgame=["blue","red","yellow","green","white","black"]

while True:
    color = colourgame[random.randint(0,len(colourgame)-1)]
    guess = input("Im thinking about a colour, can you guess it?:" )

    while True:
        if (color == guess.lower()):
            break
        else:
            guess = input("Nope, try again: ")
    
    print("You guessed it! I was thinking about", color)
    play_again = input("Lets play again? Type 'no' to quit.")
    if play_again.lower() == "no":
        break


