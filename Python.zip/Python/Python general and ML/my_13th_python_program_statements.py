print("This program asks what to compare your age with User2")


yourAge = int( input("Type your age:" )  )

userAge = int( input("Type User2 age:" )  )


if (yourAge > userAge):
    print("You are Older than User2 - ", yourAge,"is greater than",userAge)
elif (yourAge == userAge):
    print("You are same age as User2 - ",yourAge,"is equal to",userAge)
else:
    print("You are younger than User2 - ", yourAge,"is less than",userAge)
