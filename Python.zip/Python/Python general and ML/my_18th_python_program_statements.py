print("This program uses for loops")
print()
blog_posts = ["","","Coolest 10 math functions in Python","","How to make HTTP requests in Pyhton","About Data Types in Python","Modules in Python"]

for post in blog_posts:
    if post == "":
        continue
    else:
        print(post)

print("--------------------------------------------------------")

myString = "This is a string"

for char in myString:
    print(char)

print("--------------------------------------------------------")

for x in range(0,10):
    print(x)

print("--------------------------------------------------------")


person = {"Name": "Karen Smith", "Age": 25, "Gender": "Female"}
for key in person:
    print(key, ":", person[key])

print("--------------------------------------------------------")

# while loop with a dictionary object

blog_posts = {"Python": ["Coolest 10 math functions in Python","","How to make HTTP requests in Pyhton","About Data Types in Python","Modules in Python"], "Javascript":["Namespaces in Javascript","New functions available in JS6"]}

for category in blog_posts:
    print("Posts about", category)
    for post in blog_posts[category]:
        print(post)
