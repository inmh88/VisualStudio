import os
os.system('cls')

print("This program uses SciKit learn; Pandas modules, the KNN statistical model, IRIS dataset, to generate a small ML model")

from sklearn.datasets import load_iris
iris = load_iris()
print(iris.data)

print(iris.target)
print (iris.target_names)
print(type(iris.target))

print(iris.data.shape)	

from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=1)                         # set K = 1

X = iris.data
Y = iris.target

knn.fit(X,Y)

# from the data below, ML should classify this as species 0 
print( knn.predict ( [ [5.1,3.5,1.4,0.2 ] ] ) )

# from the data below, ML should classify this as species 2
print( knn.predict ( [ [5.9,3,5.1,1.8 ] ] ) )


# import the function to train and test the ML
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X,Y, test_size=0.25)        # test_size=0.4, random_state=42)  # will get a more consistent result for A/B testing
print(x_test.shape)
print(x_train.shape)


# feed the train data into the ML function to train the model
knn.fit(x_train, y_train)

# Get the ML model to predict what it thinks using the trained model, on the test data
# Print out computers results
predictions = knn.predict(x_test)
print(predictions)

# Print and compare against the oringinal y to see any difference between trained model predictions vs actual y
# (it gets it right most of the time)
print(y_test)


# Measure the performance of the model. Use a dedicated function to compare the metrics of the predicted vs actual for accuracy, will give a percentage score (0.94).
# the prediction score might be slightly different as the 'train_test_split' module randomly splits and allocates the datasets
from sklearn import metrics
performance = metrics.accuracy_score(y_test, predictions)
print(performance)

