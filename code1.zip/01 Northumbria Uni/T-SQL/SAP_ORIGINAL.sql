SET NOCOUNT ON;

--TRUNCATE TABLE dbo.sits_sap_fiorders  -- output table       
--TRUNCATE TABLE dbo.sits_sap_ftr_sent  -- temporary table picked up by SAP_FIMaster process so that       
-- master records are output for the sales orders created by this process. 

  SET concat_null_yields_null off 
   
  /* For reads and data manipulation */ 
  DECLARE  @fih_invd DATETIME 
  ,  @ftr_amnt FLOAT(8) 
  ,  @ftr_crsc CHAR(12) 
  ,  @ftr_blok CHAR(2) 
  ,  @ftr_occl CHAR(1)
  ,  @full_occl CHAR(2)
  ,  @ftr_dbtc CHAR(10) 
  ,  @ftr_fdtc CHAR(6) 
  ,  @ftr_tref CHAR(15) 
  ,  @fdg_code CHAR(6) 
  ,  @ftr_ayrc CHAR(6)             
  ,  @fee_str_amount VARCHAR(8) 
  ,  @sales_office CHAR(4) 
  ,  @sap_fao CHAR(40) 
  ,  @material_number CHAR(18) 
  ,  @delivery_date CHAR(8) 
  ,  @fee_amount CHAR(13) 
  ,  @payment_type CHAR(1) 
  ,  @payment_terms CHAR(4) 
  ,  @student_no CHAR(8) 
  ,  @prev_tref CHAR(15)
  ,  @acc_year CHAR(6)  -- Academic Year 
  ,  @acc_year1 CHAR(1) 
  ,  @sce_moac CHAR(6) 
  ,  @stu_uhoc CHAR(1) 
  ,  @crs_qulc CHAR(3) 
  ,  @crs_dptc CHAR(12) 
  ,  @rou_code CHAR(12) 
  ,  @month_released CHAR(2)  
  ,  @payterm_id CHAR(10) 
  ,  @moa CHAR(2) 
  ,  @ftr_type CHAR(1)
  ,  @ftr_stat CHAR(1) 
  ,  @route CHAR(9) 
  ,  @fee_element CHAR(1) 
  ,  @school VARCHAR(10) 
  ,  @school_name VARCHAR(20) 
  ,  @newcont CHAR(1)
                                       


   /* Fixed output fields */ 
  DECLARE  @vbak_header CHAR(4) 
  ,  @data_source CHAR(2) 
  ,  @sales_doc_type CHAR(4) 
  ,  @header_date CHAR(8) 
  ,  @fees CHAR(20) 
                          
  SET @vbak_header = 'VBAK' 
  SET @data_source = 'OT' 
  SET @header_date = CONVERT(CHAR(8),Getdate(),112) -- date in format YYYYMMDD 
  SET @fees = 'FEES' 

SELECT @output_line = (@vbak_header + Substring((@data_source + Space(2)),1,2) + Substring((@sales_doc_type + Space(4)),1,4) + Substring((@sales_office + Space(4)),1,4) + Substring((@header_date + Space(8)),1,8) + Substring((@sap_fao + Space(40)),1,40) + Substring((@s_student_no + Space(10)),1,10) + Substring((@fees + Space(20)),1,20) + Substring((@ftr_tref + Space(15)),1,15) + Substring((@school + Space(10)),1,10) + Substring(@ftr_ayrc,1,4)) 

SELECT @output_line = 'VBAK' + CONVERT(CHAR(2),'OT') + CONVERT(CHAR4),'')
  
  DECLARE  @vbap_header CHAR(4) 
  ,  @vrkme CHAR(3) 
  ,  @quantity CHAR(18) 
  ,  @profit_centre CHAR(10) 
  ,  @item_text CHAR(40) 
  ,  @int_order_no CHAR(10) 
  ,  @kschl CHAR(4) 
  ,  @s_student_no CHAR(10) 
                                      
  /* Fixed fields */ 
  SET @vbap_header = 'VBAP' 
  SET @quantity = '000000000000001000' 
  SET @vrkme = Space(3) 
  SET @profit_centre = Space(10) 
  SET @item_text = Space(40) 
  SET @int_order_no = Space(10) 
  SET @kschl = 'PR00' 
                        
  /* Output buffer */ 
  DECLARE  @output_line CHAR(250) 
                                     
  /* Current academic enrolment year */ 
  SELECT @acc_year = Substring((SELECT CONVERT(VARCHAR(12),syp_pval) 
                                                FROM   sipr.dbo.men_syp 
                                                WHERE  syp_code = 'SRS_QAEO_042'),1,6) 
   
  SELECT @acc_year1 = Substring((SELECT CONVERT(VARCHAR(12),syp_pval) 
                                                 FROM   sipr.dbo.men_syp 
                                                 WHERE  syp_code = 'SRS_QAEO_042'),4,1) 
                                 
  SET @prev_tref = 'ZZZZZZZZZZZZZZZ' 
                              
  
  
  FOR UPDATE 
   
  BEGIN 
   
      OPEN sap_cursor 
       
      FETCH NEXT FROM sap_cursor 
      INTO @student_no, 
             @ftr_tref, 
             @sales_office, 
             -- @sap_fao, 
             @ftr_crsc, 
             @ftr_blok,
            @ftr_occl, 
             @full_occl,
            @ftr_fdtc, 
             @fih_invd, 
             @ftr_amnt, 
             @payment_type, 
             @ftr_dbtc, 
             @sce_moac, 
             @stu_uhoc, 
             @crs_qulc, 
             @crs_dptc, 
             @payterm_id, 
             @ftr_type, 
             @rou_code, 
             @fdg_code, 
             @school, 
             @school_name, 
             @ftr_ayrc,
            @ftr_stat 
              
      WHILE (@@FETCH_STATUS <> -1) 
        BEGIN 
         
 

SELECT
             
            /* Change SLC and SAAS sponsor refs to those used in SAP */ 
            IF @ftr_dbtc = 'SLC'
                  BEGIN
                        SET @ftr_dbtc = CASE 
                              WHEN @ftr_ayrc = '2010/1'  THEN '0000028135' 
                              WHEN @ftr_ayrc = '2011/2'  THEN '0000028136' 
                              WHEN @ftr_ayrc = '2012/3'  THEN '0000028137' 
                              WHEN @ftr_ayrc = '2013/4'  THEN '0000028138' 
                              WHEN @ftr_ayrc = '2014/5'  THEN '0000028139' 
                              WHEN @ftr_ayrc = '2015/6'  THEN '0000028140' 
                              WHEN @ftr_ayrc = '2016/7'  THEN '0000028141' 
                              WHEN @ftr_ayrc = '2017/8'  THEN '0000028142' 
                              WHEN @ftr_ayrc = '2018/9'  THEN '0000028143' 
                              WHEN @ftr_ayrc = '2019/0'  THEN '0000028144' 
                              WHEN @ftr_ayrc = '2020/1'  THEN '0000028145' 
                              ELSE '0000006154' 
                        END 
                  END

            IF @ftr_dbtc = 'SAAS'
                  BEGIN
                        SET @ftr_dbtc = '0000000319' 
                  END 
                                                                                                             
            IF @ftr_tref <> @prev_tref 
              BEGIN 
               
                  /*   VBAK output line - 1 per student */ 
                   
                  -- vbak_header derived from ftr_type - invoice or credit, and ftr_stat - print or manual
                  -- also only self funded students get emails
                  SET @sales_doc_type = CASE
                                                      WHEN @ftr_type = 'I' AND @ftr_stat = 'P' THEN 'ZTU'
                                                      WHEN @ftr_type = 'C' AND @ftr_stat = 'P' THEN 'ZCRT'
                                                      WHEN @ftr_type = 'I' AND @ftr_stat = 'M' THEN 'ZTUP'
                                                      WHEN @ftr_type = 'C' AND @ftr_stat = 'M' THEN 'ZCRP'
                                                  END          
                                                       
                  SET @s_student_no = 'S' + @student_no 
                                                         
                  SELECT @output_line = (@vbak_header + Substring((@data_source + Space(2)),1,2) + Substring((@sales_doc_type + Space(4)),1,4) + Substring((@sales_office + Space(4)),1,4) + Substring((@header_date + Space(8)),1,8) + Substring((@sap_fao + Space(40)),1,40) + Substring((@s_student_no + Space(10)),1,10) + Substring((@fees + Space(20)),1,20) + Substring((@ftr_tref + Space(15)),1,15) + Substring((@school + Space(10)),1,10) + Substring(@ftr_ayrc,1,4)) 
                                                   
                  BEGIN TRANSACTION 
                   
                  INSERT INTO sits_sap_fiorders
                                 (sits_sap_line) 
                  SELECT @output_line 
                              
                  COMMIT TRANSACTION 
                   
                  SET @prev_tref = @ftr_tref 
              END -- if new student 
               
            /*  store month for calculating payment terms */ 
            SET @month_released = Substring(CONVERT(CHAR(8),@fih_invd,112),5,2) -- MM portion of date in YYYYMMDD 
                                             
            /* SAP mode of attendance code */ 
            SET @moa = CASE 
                               WHEN @sce_moac = '01' 
                                       OR @sce_moac = '02' 
                                       OR @sce_moac = '23' 
                                       OR @sce_moac = '24' 
                                       OR @sce_moac = '23YO' 
                                       OR @sce_moac = '24YO' 
                                       OR @sce_moac = '43' -- Added AH 19-12-2013
                                       OR @sce_moac = '64' -- Added AH 19-12-2013
                                       OR @sce_moac = '73' -- Added AH 19-12-2013
                                       OR @sce_moac = '63' THEN 'FT' 
                               ELSE 'PT' 
                           END                   
 
            -- Decide if new or continuing
            SET @newcont = (CASE WHEN EXISTS (SELECT 1
                                                                        FROM
                                                                              sipr.dbo.srs_sce                                                 
                                                                        WHERE sce_stuc = @student_no AND 
                                                                                sce_ayrc < finance.dbo.udfAcademicYear('C') AND
                                                                                sce_rouc <> 'ELL4' AND
                                                                                sce_stac <> 'IV' AND
                                                                                sce_stac NOT LIKE 'P%' )
                                                  THEN 'C'
                                                  ELSE 'N'
                                    END)       
            
         /*  Calculate payment terms */ 
            SET @payment_terms = CASE
                        
            -- rule ??
            WHEN @ftr_ayrc < @acc_year 
            THEN -- ******* Previous year - payable immediately *******
              'U001' 

            -- Removed by AH for rules 18/19 (Penspen) 05/09/2013
            --WHEN @rou_code = 'PIM6'
            --THEN
            --'U001' 
                     
            -- rule 1
            WHEN Substring(@ftr_dbtc,2,8) <> Substring(@student_no,1,8)
              THEN -- ******* sponsored students *******
              CASE      WHEN @month_released = '08' THEN 'C' + @acc_year1 + '61' -- August
                        ELSE 'U002'                                                                   -- Any other month
              END 

            -- rule 2
            WHEN @ftr_amnt <= 500 AND @ftr_crsc NOT IN ('15PLPF-N', '15FLPF-N', '15FLPR-N', '21FLUG-N', '21FLUW-N') 
              THEN  -- ******* Low value ignoring certain law courses *******
              CASE      WHEN @month_released = '08' THEN 'C' + @acc_year1 + '61' -- August *CHANGE 2013* - was 71
                        ELSE 'U002'                                                                   -- Any other month
              END
   
             -- rule 3
            WHEN @ftr_crsc LIKE '33FEL%N' AND (@stu_uhoc = 'H' OR @stu_uhoc = 'O')
              THEN -- ******* Overseas ELAN *******
                  'U005'

            -- rule 20
            --WHEN @ftr_crsc = '14PPEP-U'
            WHEN @ftr_crsc in ('14PPEP-U','16PPEN-U') -- AH 22-08-13 new Penspend code
              THEN -- ******* Overseas ELAN *******
                  'U005'      
            -- rule 6 (and partly 7 up to October)
            WHEN @stu_uhoc = 'H' AND @moa = 'FT' 
                    AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')) 
                    AND @payment_type = 'D'  
                  AND NOT (@ftr_crsc = '21FICM-N' and @rou_code = 'LIB1')
                    AND @newcont = 'C'
            THEN -- ******* Home F/T DD Sem 1 or Sem 2 spanners billed in Sem 1 *******
            CASE
                  WHEN @month_released = '08' -- August
                  THEN 'D' + @acc_year1 + '11'
                  WHEN @month_released = '09' -- September
                  THEN 'D' + @acc_year1 + '12'
                  WHEN @month_released = '10' -- October
                  THEN 'D' + @acc_year1 + '13'
                  WHEN @month_released = '11' -- November
                  THEN 'D' + @acc_year1 + '14'
                  WHEN @month_released = '12' -- December
                  THEN 'D' + @acc_year1 + '15'
                  WHEN @month_released = '01' -- January
                  THEN 'D' + @acc_year1 + '16'
                  ELSE 'DD14'                       -- February or later
            END   
            
            -- rule 7 (Nov onwards)
            WHEN @stu_uhoc = 'H' AND @moa = 'FT' 
                    AND @ftr_occl >= 'F' 
                    AND @payment_type = 'D'
                  AND NOT (@ftr_crsc = '21FICM-N' and @rou_code = 'LIB1')
                    AND @newcont = 'C'
            THEN -- ******* Home F/T DD Sem 2 *******
            CASE
                  WHEN @month_released = '11' -- November
                  THEN 'D' + @acc_year1 + '24'
                  WHEN @month_released = '12' -- December
                  THEN 'D' + @acc_year1 + '25'
                  WHEN @month_released = '01' -- January
                  THEN 'D' + @acc_year1 + '26'
                  WHEN @month_released = '02' -- February
                  THEN 'D' + @acc_year1 + '27'
                  WHEN @month_released = '03' -- March
                  THEN 'D' + @acc_year1 + '28'
                  WHEN @month_released = '04' -- April
                  THEN 'D' + @acc_year1 + '29'
                  ELSE 'DD14'                       -- May or later
            END
            
            -- rule 17
            WHEN (@ftr_crsc = '21PLUG-N' OR @ftr_crsc = '21PLAW-N' )
                    AND @payment_type = 'C'
            THEN
            CASE
                  WHEN @month_released = '08' -- August
                  THEN 'C' + @acc_year1 + '11'
                  WHEN @month_released = '09' -- September
                  THEN 'C' + @acc_year1 + '12'
                  WHEN @month_released = '10' -- October
                  THEN 'C' + @acc_year1 + '13'
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '14'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '15'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '16'
                  ELSE 'U005'                       -- February or later
            END   
            -- RULE 18,19,20,21
            WHEN (@ftr_crsc LIKE '10%' OR @ftr_crsc LIKE '11%' OR @ftr_crsc LIKE '12%') -- Research Students Programmes
                        AND @ftr_amnt > 500 
            THEN
                  CASE  
                        WHEN (@moa = 'FT' AND @payment_type = 'C') -- Full Time Cash rule 18
                        THEN 'RC01'
                        WHEN (@moa = 'FT' AND @payment_type = 'D') -- Full time Direct Debit rule 19
                        THEN 'RD01' 
                        WHEN (@moa = 'PT' AND @payment_type = 'C') -- Part Time Cash rule 20
                        THEN 'RC02'
                        WHEN (@moa = 'PT' AND @payment_type = 'D') -- Part Time Direct Debit rule 21
                        THEN 'RD02'
                  END
            -- Removed by AH below line on 21-08-13 for Penspen
            -- rule 18 (and 19 up to October)
            --WHEN (@ftr_crsc = '16PPEN-U' OR @ftr_crsc = '16PPEN-U' OR @ftr_crsc = '15PPES-U' )
            WHEN (@ftr_crsc in ('16PPEP-U' , '15PPEP-U' )) -- AH added on 22-08-13 for new Penspen codes
            
            AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')) 
            AND @payment_type = 'C'
            THEN
            CASE
                  WHEN @month_released = '08' -- August
                  THEN 'C' + @acc_year1 + '69'
                  WHEN @month_released = '09' -- September
                  THEN 'C' + @acc_year1 + '70'
                  WHEN @month_released = '10' -- October
                  THEN 'C' + @acc_year1 + '71'
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '72'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '73'
                  ELSE 'U005'                       -- February or later
            END   

            -- rule 19 (Nov onwards)
            -- AH, below line removed for new Penspen
            --WHEN (@ftr_crsc = '16PPEN-U' OR @ftr_crsc = '16PPES-U' OR @ftr_crsc = '15PPES-U' )
            WHEN (@ftr_crsc in ('16PPEP-U' , '15PPEP-U' )) -- AH added on 22-08-13 for new Penspen
                    AND @ftr_occl >= 'F' 
                    AND @payment_type = 'C'
            THEN
            CASE
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '74'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '75'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '76'
                  WHEN @month_released = '02' -- Feb
                  THEN 'C' + @acc_year1 + '77'
                  WHEN @month_released = '03' -- March
                  THEN 'C' + @acc_year1 + '78'
                  ELSE 'U005'                       -- later
            END   

            -- rule 4 (or 5 up to October)
            WHEN (@stu_uhoc = 'H' AND @moa = 'FT'
                    AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2'))
                  AND NOT (@ftr_crsc = '21FICM-N' and @rou_code = 'LIB1')
                  )
            THEN -- ******* Home F/T Cash Sem 1 or Sem 2 spanners billed in Sem 1 *******
            CASE
                  WHEN @month_released = '08' -- August
                  THEN 'C' + @acc_year1 + '11'
                  WHEN @month_released = '09' -- September
                  THEN 'C' + @acc_year1 + '12'
                  WHEN @month_released = '10' -- October
                  THEN 'C' + @acc_year1 + '13'
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '14'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '15'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '16'
                  ELSE 'U005'                       -- February or later
            END   
                  
            -- rule 5
            WHEN @stu_uhoc = 'H' AND @moa = 'FT' AND @ftr_occl >= 'F'
                  AND NOT (@ftr_crsc = '21FICM-N' and @rou_code = 'LIB1')
            THEN -- ******* Home F/T Cash Sem 2 *******
            CASE
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '24'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '25'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '26'
                  WHEN @month_released = '02' -- February
                  THEN 'C' + @acc_year1 + '27'
                  WHEN @month_released = '03' -- March
                  THEN 'C' + @acc_year1 + '28'
                  WHEN @month_released = '04' -- April
                  THEN 'C' + @acc_year1 + '29'
                  ELSE 'U005'                       -- May or later
            END   
            
            -- rule 10
            WHEN @moa = 'PT' 
                    AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')) 
                    AND @payment_type = 'D' 
                    AND @ftr_crsc not in ('16PPEN-U','16PPES-U','15PPES-U','21PLUG-N','21PLAW-N') 
                    -- ******* Home P/T DD Sem 1 or Sem 2 spanners billed in Sem 1 *******
            -- rule 16
            OR  ((@ftr_crsc = '14PLPT-N' OR @ftr_crsc = '14PLPF-N' OR @ftr_crsc = '14PLLM-N') AND 
                    @ftr_amnt < 2600 AND @moa = 'PT'
                        AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')) 
                         AND @payment_type = 'D') 
            -- rule 21
            OR   ( @payment_type = 'D'
              AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')) 
                  AND @ftr_crsc = '21FICM-N' AND @rou_code = 'LIB1')
            THEN -- ******* Law Scheme low value DD Sem 1 *******
            CASE
                  WHEN @month_released = '08'  -- August
                  THEN 'D' + @acc_year1 + '31'
                  ELSE 'D' + @acc_year1 + '32' -- September or later
            END   
                  
            -- rule 11
            WHEN ((@stu_uhoc = 'H' OR @stu_uhoc = 'O') AND @moa = 'PT' AND @ftr_occl >= 'F'  AND @payment_type = 'D'
                        AND @ftr_crsc not in ('16PPEN-U','16PPES-U','15PPES-U','21PLUG-N','21PLAW-N') )

                    -- ******* Home P/T DD Sem 2 *******
            -- rule 16
            OR   ((@ftr_crsc = '14PLPT-N' OR @ftr_crsc = '14PLPF-N' OR @ftr_crsc = '14PLLM-N')
                        AND @ftr_occl >= 'F'  
                    AND @ftr_amnt < 2600 AND @moa = 'PT'  AND @payment_type = 'D')
        -- rule 21
            OR   (@payment_type = 'D'
                        AND @ftr_occl >= 'F'  
                  AND @ftr_crsc = '21FICM-N' AND @rou_code = 'LIB1')
            THEN -- ******* Law Scheme low value DD Sem 2 *******
            CASE
                  WHEN @month_released = '11'  -- November
                  THEN 'D' + @acc_year1 + '44'
                  ELSE 'D' + @acc_year1 + '45' -- December or later
            END

            --rule 8
            WHEN ( @moa = 'PT' 
                         AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '12' AND @ftr_blok LIKE '_2'))
                        AND @ftr_crsc not in ('16PPEN-U','16PPES-U','15PPES-U','21PLUG-N','21PLAW-N') )
                    -- ******* Home P/T Cash Sem 1 or Sem 2 spanners billed in Sem 1 *******
            -- rule 11
            OR  ((@ftr_crsc = '14PLPT-N' OR @ftr_crsc = '14PLPF-N' OR @ftr_crsc = '14PLLM-N') AND 
                    @ftr_amnt < 2600 AND @moa = 'PT'
                        AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')))
            -- rule 16
            OR   (@ftr_crsc = '21FICM-N' AND @rou_code = 'LIB1'
                        AND (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2')))
            THEN -- ******* Law Scheme low value Cash Sem 1 *******
            CASE
                  WHEN @month_released = '08' -- August
                  THEN 'C' + @acc_year1 + '31' 
                  WHEN @month_released = '09' -- September
                  THEN 'C' + @acc_year1 + '32'
                  WHEN @month_released = '10' -- October
                  THEN 'C' + @acc_year1 + '33'
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '33'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '33'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '33'
                  ELSE 'U005'                         -- February or later
            END   
                  
            -- rule 9
            WHEN ( @moa = 'PT' AND @ftr_occl >= 'F'
                        AND @ftr_crsc not in ('16PPEN-U','16PPES-U','15PPES-U','21PLUG-N','21PLAW-N') )
                    -- ******* Home P/T Cash Sem 2 *******
            -- rule 11 
            OR   ((@ftr_crsc = '14PLPT-N' OR @ftr_crsc = '14PLPF-N' OR @ftr_crsc = '14PLLM-N') AND 
                    @ftr_amnt < 2600 AND @moa = 'PT' AND @ftr_occl >= 'F')
            -- rule 16
            OR   (@ftr_occl >= 'F'
                 AND @ftr_crsc = '21FICM-N' AND @rou_code = 'LIB1')
            THEN -- ******* Law Scheme low value Cash Sem 2 *******
            CASE
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '44'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '45'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '46'
                  WHEN @month_released = '02' -- February
                  THEN 'C' + @acc_year1 + '46'
                  WHEN @month_released = '03' -- March
                  THEN 'C' + @acc_year1 + '46'
                  WHEN @month_released = '04' -- April
                  THEN 'C' + @acc_year1 + '46'
                  ELSE 'U005'                       -- May or later
            END                                       

            
            -- rule 12 (rule 13 up to October)
            WHEN @stu_uhoc = 'O' AND @moa = 'FT' AND 
                   (@ftr_occl < 'F' OR (@ftr_occl >= 'F' AND @month_released BETWEEN '08' AND '10' AND @ftr_blok LIKE '_2'))
            THEN -- ******* Overseas F/T Cash Sem 1 or Sem 2 spanners billed in Sem 1 *******
            CASE
                  WHEN @month_released = '08' -- August
                  THEN 'C' + @acc_year1 + '51'
                  WHEN @month_released = '09' -- September
                  THEN 'C' + @acc_year1 + '52'
                  WHEN @month_released = '10' -- October
                  THEN 'C' + @acc_year1 + '53'
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '54'
                  ELSE 'U001'                       -- December or later 
            END   
                  
            -- rule 13
            WHEN @stu_uhoc = 'O' AND @moa = 'FT' AND @ftr_occl >= 'F'
            THEN -- ******* Overseas F/T Cash Sem 2 *******
            CASE
                  WHEN @month_released = '11' -- November
                  THEN 'C' + @acc_year1 + '64'
                  WHEN @month_released = '12' -- December
                  THEN 'C' + @acc_year1 + '65'
                  WHEN @month_released = '01' -- January
                  THEN 'C' + @acc_year1 + '66'
                  WHEN @month_released = '02' -- February
                  THEN 'C' + @acc_year1 + '67'
                  WHEN @month_released = '03' -- March
                  THEN 'C' + @acc_year1 + '68'
                  ELSE 'U001'                       -- April or later 
            END                                       
                    -- ******* If the records do not fall into any of the above categories, payable immediately *******        
             ELSE 'U001' 
                     
            END             
                                                                          
            -- Form the material number = 'Z' + course(6 digits) + route(9 digits padded with zeroes) 
            -- + 1st digit of stage + fee-element 
            SET @route = Rtrim(@rou_code) + Replicate('0',9 - Datalength(Rtrim(@rou_code))) 
                                                             
            -- Translation of fee data group to SAP fee element 
            SET @fee_element = CASE 
                                           WHEN @fdg_code = 'TF' THEN '1' 
                                           WHEN @fdg_code = 'RF' THEN '2' 
                                           WHEN @fdg_code = 'PF' THEN '3' 
                                           WHEN @fdg_code = 'RES' THEN '4' 
                                           WHEN @fdg_code = 'EXAM' THEN '5' 
                                           WHEN @fdg_code = 'MAT' THEN '6' 
                                           WHEN @fdg_code = 'TOPUP' THEN '7' 
                                           ELSE '?' 
                                       END 
                                          
            SET @material_number = 'Z' + LEFT(@ftr_crsc,6) + @route + LEFT(@ftr_blok,1) + @fee_element 
                                                                                                                                 
            -- SET @delivery_date = CONVERT(CHAR(8),@fih_invd,112) -- date in format YYYYMMDD 
            -- 29/10/2009 use today's date rather than ftr creation date
            SET @delivery_date = CONVERT(CHAR(8), Getdate(),112)   -- date in format YYYYMMDD
                                    
            SET @fee_str_amount = Ltrim(REPLACE(Str(@ftr_amnt,8,2),'.','')) 
                                             
            SET @fee_amount = Replicate('0',13 - Datalength(@fee_str_amount)) + @fee_str_amount 
                                                                                                                   
            /*  VBAP output line - 1 per fee */ 
            SELECT @output_line = (@vbap_header + Substring((@material_number + Space(18)),1,18) + Substring((@vrkme + Space(3)),1,3) + Substring((@quantity + Space(18)),1,18) + Substring((@delivery_date + Space(8)),1,8) + Substring((@fee_amount + Space(13)),1,13) + Substring((@profit_centre + Space(10)),1,10) + Substring((@item_text + Space(40)),1,40) + Substring((@int_order_no + Space(10)),1,10) + @kschl + Substring((@payment_terms + Space(4)),1,4) + Substring((@ftr_dbtc + Space(10)),1,10)) 
             
            BEGIN TRANSACTION 
             
            INSERT INTO sits_sap_fiorders
                           (sits_sap_line) 
            SELECT @output_line 
            
            INSERT INTO sits_sap_audit 
                           (ftr_tref, 
                              school, 
                              course, 
                              route, 
                              h_o, 
                              moa, 
                              qual_aim, 
                              ftr_amount, 
                              ftr_pstd, 
                              academic_year) 
            SELECT @ftr_tref, 
                     @school + ' ' + @school_name, 
                     @ftr_crsc, 
                     @rou_code, 
                     @stu_uhoc, 
                     @moa, 
                     CASE 
                         WHEN LEFT(@ftr_crsc,2) < 21 THEN 'PG' 
                         ELSE 'UG' 
                     END, 
                     CASE 
                         WHEN @ftr_type = 'I' THEN @ftr_amnt 
                         ELSE 0 - @ftr_amnt 
                     END, 
                     Dateadd(dd,Datediff(dd,0,Getdate()),0), 
                     @ftr_ayrc 
                        
            /*  Set FTR record to posted status */ 
            UPDATE sipr.dbo.srs_ftr 
            SET    ftr_post = 'Y', 
                     ftr_pstd = Dateadd(dd,Datediff(dd,0,Getdate()),0) 
            WHERE CURRENT OF sap_cursor 

            
            COMMIT TRANSACTION 
             
            FETCH NEXT FROM sap_cursor 
            INTO @student_no, 
                   @ftr_tref, 
                   @sales_office, 
                   --    @sap_fao, 
                   @ftr_crsc, 
                   @ftr_blok,
                  @ftr_occl, 
                   @full_occl, 
                   @ftr_fdtc, 
                   @fih_invd, 
                   @ftr_amnt, 
                   @payment_type, 
                   @ftr_dbtc, 
                   @sce_moac, 
                   @stu_uhoc, 
                   @crs_qulc, 
                   @crs_dptc, 
                   @payterm_id, 
                   @ftr_type, 
                   @rou_code, 
                   @fdg_code, 
                   @school, 
                   @school_name, 
                   @ftr_ayrc,
                  @ftr_stat  
                    
        END -- fetch loop 
         
      CLOSE sap_cursor 
       
      DEALLOCATE sap_cursor 
      
END
END


This message is intended solely for the addressee and may contain confidential and/or legally privileged information. Any use, disclosure or reproduction without the sender’s explicit consent is unauthorised and may be unlawful. If you have received this message in error, please notify Northumbria University immediately and permanently delete it. Any views or opinions expressed in this message are solely those of the author and do not necessarily represent those of the University. The University cannot guarantee that this message or any attachment is virus free or has not been intercepted and/or amended. 
