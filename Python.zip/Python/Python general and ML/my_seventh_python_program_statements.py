
#Lists
students = ["John","Mary","Steve"]
type(students)
print( students[0] )
print( students[-1] )
print( students[:2] )


#Tuples
months = ["Jan","Feb","Mar"]
type(months)
print( months[0] )
print( months[-1] )
print( months[:2] )
