print("This program is using calcs the BMI index of a person")

vweight = float( input("What is your Weight in Kg: " ) )
vheight =  float( input("What is your Height in Meters: " ) )

vBMI = round( vweight / (vheight **2) ,2)

if (vBMI <= 18.5):
    print("You are Underweight. - ", vBMI)
elif (vBMI > 18.5 and vBMI <= 24.9):
    print("You are Normal weight. - ", vBMI)
elif (vBMI > 24.9 and vBMI <= 29.9):
    print("You are Overweight. - ", vBMI)
else:
    print("You are Obese. - ", vBMI)

