print("This program asks what field to return looks up a dictionary for that")


num1 = float( input("Type the first number:" )  )
num2 = float( input("Type the second number:" )  )


if (num1 > num2):
    print(num1,"is greater than",num2)
elif (num1 == num2):
    print(num1,"is equal to",num2)
else:
    print(num1,"is less than",num2)
