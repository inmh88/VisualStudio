print("This program opens and manipulates Excel sheets and data")

import pandas as pd

# Get the Excel file
file = pd.ExcelFile("C:\\SourceCode\\Udemy\\Python\\sales.xlsx")
print(file.sheet_names)

#Get the sheet
sheet = (file.parse("sales"))
print(sheet)
print(type(sheet))

#Get a Column
print(sheet.Date )

# Sum a numeric column
print(sheet.Amount.sum() )

#Print a specific Record/row; pandas auto adds a column number
print("\nIndividual record:\n",sheet.loc[0] )
print("\nIndividual record specific column:\n", sheet.loc[0, "Amount"] )


# Get specific Values by using a Specific Column Name (Customer)
sheet.set_index("Customer", inplace=True)  # sets the index
sheet.loc["MMC Inc"]

sheet = sheet.reset_index()   # resets the index (vlookup index)to blank 

sheet["invoice"]
type(sheet["invoice"])

#Pass in the entire series (set of data) and get invoice 99
sheet.loc[ sheet["invoice"] == 99 ]

# return greater than amount 
sheet.loc[ sheet["Amount"] > 2000 ]

# return highest amount
sheet.loc[ sheet["Amount"].idxmax()]

# return highest amount of the specific Customer
sheet.loc[ sheet["Amount"].idxmax()]["Customer"]

# return unique customer who has amount > 1800
sheet.loc[ sheet["Amount"] > 1800]["Customer"].unique()

# return unique customer who has amount > 1800 (first customer only)
sheet.loc[ sheet["Amount"] > 1800]["Customer"].unique()[0]

# loop through and print the customers
for customer in sheet.loc[ sheet["Amount"] > 1800]["Customer"].unique():
    print(customer)
    