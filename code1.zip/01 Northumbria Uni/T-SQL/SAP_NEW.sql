-- FINANCE ORDER EXTRACT 
-- PART 1
-- GET BASE DATA

TRUNCATE TABLE tbl_BASE_ORDERS
INSERT INTO tbl_BASE_ORDERS

SELECT   

FTR_TREF,													-- Transaction ref 
FTR_AYRC,													-- Academic year
FTR_STAT,													-- Status - P or M 
FTR_CRSC,													-- Course code 
FTR_BLOK,													-- Stage 
SUBSTRING(FTR_OCCL,1,1),									-- Occurrence 1 char
FTR_OCCL,													-- Occurrence
FTR_FDTC,													-- Fee element (will need to reduce to 1 character) 
FTR_AMNT,													-- Amount 
FTR_DBTC,													-- Debtor code 
FTR_TYPE,													-- Invoice/credit 

(CASE WHEN ISNULL(FST_FSGC,'U') = 'E' THEN 'H'				-- Residence - H/O 
      ELSE ISNULL(FST_FSGC,'U') 
END),       

CONVERT(CHAR(4),ISNULL(XON_NEWV,'')),						-- SAP sales office 
ISNULL(FIH_INVD,GETDATE()),									-- Date raised 

FDT_FDGC,													-- Fee data group code from FDT 

SCE_STUC,													-- Student 
SCE_FACC,													-- School 
FAC_SNAM,													-- School name 
CRS_DPTC,													-- Department 
CRS_QULC,													-- Qual aim 
SCE_ROUC,													-- Route code 
SCE_MOAC,													-- Mode of attendance 
SUBSTRING(ISNULL(SCE_UDF9,'C'),1,1),						-- For payment terms 
PAYTERM_ID													-- Payment method 


      -- Main student-finance table
 FROM SIPR.DBO.SRS_FTR 
 
			INNER JOIN SIPR.DBO.SRS_SCE ON
									FTR_SCJC = SCE_SCJC AND
                                    FTR_AYRC = SCE_AYRC AND                               
                                    ISNULL(FTR_AMNT,0) <> 0 
 
            INNER JOIN SIPR.DBO.INS_STU ON
                                    SCE_STUC = STU_CODE

            INNER JOIN SIPR.DBO.SRS_FAC ON
                                    SCE_FACC = FAC_CODE 

            INNER JOIN SIPR.DBO.SRS_FST ON
                                    SCE_FSTC = FST_CODE

            INNER JOIN SIPR.DBO.SRS_FIH ON
                                    FTR_TREF = FIH_TREF AND
                                    FTR_AYRC = FIH_AYRC 

            INNER JOIN SIPR.DBO.SRS_FDT ON
                                    FTR_FDTC = FDT_CODE

            INNER JOIN SIPR.DBO.SRS_CRS ON
                                    FTR_CRSC = CRS_CODE

            INNER JOIN SIPR.DBO.SRS_DBT ON
                                    FTR_DBTC = DBT_CODE
                                    
            LEFT OUTER JOIN SIPR.DBO.MEN_XON ON 
                               (    XON_TABL = 'SAP_SALES_OFFICE' AND
                                    XON_OLDV = CRS_DPTC     ) 

 --          INNER JOIN SIPR.DBO.SRS_SSP ON
 --                                   SCE_STUC = SSP_STUC AND
 --                                   FTR_AYRC = SSP_AYRC

WHERE

ISNULL(FTR_TREF,'') <> '' 	AND
FTR_POST = 'N'				AND 

(FTR_STAT = 'P' OR FTR_STAT = 'M') AND 
(SCE_STAC <> 'IV' OR (SCE_STAC = 'IV' AND FTR_TYPE = 'C')) -- Ignore invalid enrolment records unless it's a credit note


ORDER BY FTR_TREF ASC 










-- STEP 2
--- workings out....


/* SAP mode of attendance code */ 
(CASE WHEN SCE_MOAC IN('01','02','23','23YO','24','24YO','43','63','64','73') THEN 'FT'
      ELSE 'PT'
 END),

 /* SAP mode of attendance code */ 
            SET @moa = CASE 
                               WHEN @sce_moac = '01' 
                                       OR @sce_moac = '02' 
                                       OR @sce_moac = '23' 
                                       OR @sce_moac = '24' 
                                       OR @sce_moac = '23YO' 
                                       OR @sce_moac = '24YO' 
                                       OR @sce_moac = '43' -- Added AH 19-12-2013
                                       OR @sce_moac = '64' -- Added AH 19-12-2013
                                       OR @sce_moac = '73' -- Added AH 19-12-2013
                                       OR @sce_moac = '63' THEN 'FT' 
                               ELSE 'PT' 
                           END                   
						   
						   



