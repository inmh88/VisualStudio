print("This program opens reads, and writes to files")



#Explicitly CREATE a new file (modes "a" and "w" will implicitly create one if not found):
open("C:\\SourceCode\\Udemy\\Python\\test.txt", "x")


#open file for READ only (read the file f and print to screen):
f = open("C:\\SourceCode\\Udemy\\Python\\test.txt")
print( f.read() )


#open file for WRITE (overwrite the file completely with new content):
f = open("C:\\SourceCode\\Udemy\\Python\\test.txt", "w")
f.write("This text will overwrite the content of the file")


#open file for APPEND (add to the end of the file with new content):
f = open("C:\\SourceCode\\Udemy\\Python\\test.txt", "a")
f.write("\nThis text will append the content to the end of the file")
