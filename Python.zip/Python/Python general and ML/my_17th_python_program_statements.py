print("This program is uses while loops")

# with a subscript x
#x=0
#people=[]
#
#while x < 5:
#    person = input("Type the name of a person: ")
#    people.append(person)
#    x += 1
#print(people) 






# less code, uses list length
people=[]
while len(people) < 5:
    person = input("Type the name of a person: ")
    people.append(person)
print(people)





import random

print("This program is uses while loops, with a break")
#number = 5
number = random.randint(0,10)

guess = int (input ("Im thinking about a number bewteen 0 and 10, can you guess it?: ") )

while True:
    if guess == number:
        break
    else:
        guess = int (input ("Nope, try again: ") )
print("Yes, you guessed it. I was thinking about", number)
