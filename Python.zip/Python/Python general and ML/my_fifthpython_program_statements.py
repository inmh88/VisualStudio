print("This program splits a string up for parts")

varProdLotNo = "037-00901-00027"

strCountryCode = varProdLotNo[0:3]
strProductCode = varProdLotNo[4:9]
strBatchNumber = varProdLotNo[-5:]

print("Country code:",strCountryCode)
print("Product code:",strProductCode)
print("Batch Number code:",strBatchNumber)

