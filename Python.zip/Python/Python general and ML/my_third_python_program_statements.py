print("This program converts kilometers to miles")

varKm = float ( input("Please enter kilometers: ") )
varMiles = (varKm/1.609344)

print("Kilometers entered is",varKm)
print (varKm, "kilometers is", round(varMiles, 4), "miles")
