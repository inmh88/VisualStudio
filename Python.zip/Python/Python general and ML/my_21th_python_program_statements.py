print("This program uses try except error handler")

number = input("Type a number")

try:
    number = float(number)
    print("The number is:", number)
except:
    print("Invalid number")


