print("This program asks what field to return looks up a dictionary for that")

person = {"name":"John", "gender": "Male", "age": 19, "address": "18 Lawson Close, Byker, UK", "phone": "0191 333444"}
list1 = list(person.keys())
print("The available fields are:", list1)

varInputName = input("Please enter the field you would like: ").lower
message = person.get(varInputName,"sorry not found")	
print(message)


