print("This program asks User for Name of User and adds to the the register")

listUsers = ["Fred","Barney","Nathan","Ashok","Ahmed","James","Rich"]
varInputName = input("Please enter your Name: ") 

listUsers.append(varInputName)

print("Users list:",listUsers)
